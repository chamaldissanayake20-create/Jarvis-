package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

const val SYSTEM = "You are JARVIS, a voice assistant on the user's Android phone. The user speaks Sinhala or English; reply in the language they used. Keep replies to 1-2 short sentences. Use the functions to act on the phone."
const val DECLS = """[
{"name":"flashlight","description":"Turn flashlight on/off","parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
{"name":"call","description":"Open dialer with a number","parameters":{"type":"object","properties":{"number":{"type":"string"}},"required":["number"]}},
{"name":"send_sms","description":"Open SMS composer","parameters":{"type":"object","properties":{"number":{"type":"string"},"message":{"type":"string"}},"required":["number","message"]}},
{"name":"open_app","description":"Open an installed app by its name (YouTube, WhatsApp, ...)","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
{"name":"open_url","description":"Open a URL or web search in the browser","parameters":{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}},
{"name":"set_volume","description":"Set media volume 0-15","parameters":{"type":"object","properties":{"level":{"type":"integer"}},"required":["level"]}},
{"name":"battery","description":"Get battery percentage"},
{"name":"set_alarm","description":"Set alarm, 24h time","parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"}},"required":["hour","minute"]}},
{"name":"wifi_settings","description":"Open WiFi settings"}
]"""

class MainActivity : Activity() {
    lateinit var web: WebView
    lateinit var tts: TextToSpeech
    var rec: SpeechRecognizer? = null
    val history = JSONArray()
    val prefs by lazy { getSharedPreferences("j", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Jarvis")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        tts = TextToSpeech(this) {}
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    fun js(fn: String, arg: String) = runOnUiThread { web.evaluateJavascript("$fn(${JSONObject.quote(arg)})", null) }

    inner class Bridge {
        @JavascriptInterface fun listen(lang: String) { runOnUiThread { startListening(lang) } }
        @JavascriptInterface fun ask(t: String) { Thread { think(t) }.start() }
        @JavascriptInterface fun save(key: String, model: String) { prefs.edit().putString("key", key.trim()).putString("model", model.trim().ifEmpty { "gemini-flash-lite-latest" }).apply() }
        @JavascriptInterface fun getModel(): String = prefs.getString("model", "gemini-flash-lite-latest")!!
    }

    fun startListening(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { js("onReply", "Mic permission දීලා ආයෙ tap කරන්න"); return }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle) {
                val t = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) { js("onHeard", t); Thread { think(t) }.start() } else js("onState", "")
            }
            override fun onError(e: Int) { js("onState", ""); js("onReply", "හරියට ඇහුණේ නැහැ (error $e)") }
            override fun onReadyForSpeech(p: Bundle?) { js("onState", "listen") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang))
    }

    fun reply(t: String) {
        js("onReply", t); js("onState", "")
        runOnUiThread {
            val si = Locale("si", "LK")
            val sinhala = Regex("[\u0D80-\u0DFF]").containsMatchIn(t) && tts.isLanguageAvailable(si) >= TextToSpeech.LANG_AVAILABLE
            tts.setLanguage(if (sinhala) si else Locale.US)
            tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
        }
    }

    fun think(text: String) {
        js("onState", "think")
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { reply("⚙ එකෙන් Gemini key එක දාන්න."); return }
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        try {
            repeat(6) {
                val content = callGemini(key).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                history.put(content)
                val parts = content.optJSONArray("parts") ?: JSONArray()
                val results = JSONArray()
                var out = ""
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("functionCall")) {
                        val c = p.getJSONObject("functionCall")
                        val r = try { act(c.getString("name"), c.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "error: ${e.message}" }
                        results.put(JSONObject().put("functionResponse", JSONObject().put("name", c.getString("name")).put("response", JSONObject().put("result", r))))
                    } else out += p.optString("text")
                }
                if (results.length() == 0) { reply(out.ifEmpty { "Done." }); return }
                history.put(JSONObject().put("role", "user").put("parts", results))
            }
            reply("Done.")
        } catch (e: Exception) { reply("error: ${e.message?.take(160)}") }
    }

    fun callGemini(key: String): JSONObject {
        val model = prefs.getString("model", "gemini-flash-lite-latest")
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", history)
            .put("tools", JSONArray().put(JSONObject().put("function_declarations", JSONArray(DECLS))))
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val s = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception(if (code == 429) "Free limit reached, පස්සේ try කරන්න" else "HTTP $code: ${s.take(150)}")
        return JSONObject(s)
    }

    fun act(n: String, a: JSONObject): String {
        fun go(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        when (n) {
            "flashlight" -> { val cm = getSystemService(CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], a.getBoolean("on")) }
            "call" -> go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.getString("number"))))
            "send_sms" -> go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + a.getString("number"))).putExtra("sms_body", a.getString("message")))
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
            "open_app" -> {
                val q = a.getString("name").lowercase(); val pm = packageManager
                val li = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val m = li.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return "app not found"
                go(pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!)
            }
            "set_volume" -> { val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_MUSIC, a.getInt("level") * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 15, 0) }
            "battery" -> { val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); return "${i?.getIntExtra("level", 0)}%" }
            "set_alarm" -> go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "wifi_settings" -> go(Intent(Settings.ACTION_WIFI_SETTINGS))
            else -> return "unknown action"
        }
        return "done"
    }
}
